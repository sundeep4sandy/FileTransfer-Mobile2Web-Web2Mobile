package com.lakj.comspace.filetransfer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class server extends Activity {

	private Socket client;
	private PrintWriter printwriter;
	private EditText textField;
	private Button button;
	private String messsage;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.server);

		textField = (EditText) findViewById(R.id.editText1); // reference to the text field
		button = (Button) findViewById(R.id.button1); // reference to the send button
        Button receive=(Button)findViewById(R.id.button);
        receive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent rec= new Intent(server.this,MainActivity.class);
                startActivity(rec);
            }
        });
		// Button press event listener
		button.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {
				messsage = textField.getText().toString(); // get the text message on the text field
				textField.setText(""); // Reset the text field to blank
				SendMessage sendMessageTask = new SendMessage();
				sendMessageTask.execute();
			}
		});
	}

	private class SendMessage extends AsyncTask<Void, Void, Void> {

		@Override
		protected Void doInBackground(Void... params) {
			try {

				client = new Socket("192.168.0.5", 4444);

				String a="fileList ";
                String path= Environment.getExternalStorageDirectory().toString();

                File fileList = new File(path+"/networks");
				if (fileList != null) {
					File[] filenames = fileList.listFiles();
					for (File tmpf : filenames){
						a=a+tmpf.getName();
                        a=a+"   ";
					}
				}

				printwriter = new PrintWriter(client.getOutputStream(), true);
				printwriter.write(a); // write the message to output stream

				printwriter.flush();
				printwriter.close();


                client = new Socket("192.168.0.5", 4444);

                InputStreamReader inputStreamReader = new InputStreamReader(client.getInputStream());
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader); // get the client message

                String name = bufferedReader.readLine();
                client = new Socket("192.168.0.5", 4444);
                Log.d("filename", "hii");
                    BufferedReader br = new BufferedReader(new FileReader(path + "/networks/"+name));
                    StringBuilder sb = new StringBuilder();
                    String line = br.readLine();
                    Log.d("filename1", line);
                    while (line != null) {
                        sb.append(line);
                        sb.append(System.lineSeparator());
                        line = br.readLine();
                    }
                    String everything = sb.toString();
                    printwriter = new PrintWriter(client.getOutputStream(), true);
                    printwriter.write(everything); // write the message to output stream

                    printwriter.flush();
                    printwriter.close();

                client.close(); // closing the connection


            } catch (UnknownHostException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
            return null;
		}

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.slimple_text_client, menu);
		return true;
	}

}
