package com.lakj.comspace.filetransfer;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Environment;

import android.util.Log;
import android.view.View;

import android.app.Activity;
import android.os.AsyncTask;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.logging.Handler;
import java.util.logging.LogRecord;

public class MainActivity extends Activity {

    private ListView mList;
    private ArrayList<String> arrayList;
    private listname mAdapter;
    private TCPClient mTcpClient;
    int serverResponseCode = 0;
    ProgressDialog dialog = null;
    final String uploadFilePath = "/storage/emulated/0/";
    final String uploadFileName = "demo.txt";
    String upLoadServerUri = null;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        arrayList = new ArrayList<String>();

        final EditText editText = (EditText) findViewById(R.id.editText);
        Button send = (Button) findViewById(R.id.send_button);
        Button recieve = (Button) findViewById(R.id.recieve_button);
        //relate the listView from java to the one created in xml
        mList = (ListView) findViewById(R.id.list);
        mAdapter = new listname(this, arrayList);
        mList.setAdapter(mAdapter);


        Handler mHandler;
        mHandler = new Handler() {
            @Override
            public void close() {

            }

            @Override
            public void flush() {

            }

            @Override
            public void publish(LogRecord record) {

            }
        };

        mList.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //Toast.makeText(getBaseContext(), parent.getItemAtPosition(position) + "is selected", Toast.LENGTH_LONG).show();
                TextView textView = (TextView) view.findViewById(R.id.list_item_text_view);
                String text = textView.getText().toString();
                System.out.println("Choosen File = : " + text);
                if (mTcpClient != null) {
                    mTcpClient.sendMessage("RequestingFile");
                    mTcpClient.sendMessage(text);
                }


                Toast.makeText(getBaseContext(), "File is Downloaded successfully at location..", Toast.LENGTH_LONG).show();

            }
        });
        // connect to the server
        new connectTask().execute("");
        upLoadServerUri = "http://192.168.1.150/C:/xampp/htdocs/DB/UploadToServer.php";

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                dialog = ProgressDialog.show(MainActivity.this, "", "Uploading file...", true);

                new Thread(new Runnable() {
                    public void run() {
                        runOnUiThread(new Runnable() {
                            public void run() {
                                editText.setText("uploading started.....");
                            }
                        });

                        uploadFile(uploadFilePath + "" + uploadFileName);
                    }
                }).start();

                //------------ENDS HERE
            }


            //----- uploadFile Code starts here--

            public int uploadFile(String sourceFileUri) {

                String fileName = sourceFileUri;

                HttpURLConnection conn = null;
                DataOutputStream dos = null;
                String lineEnd = "\r\n";
                String twoHyphens = "--";
                String boundary = "*****";
                int bytesRead, bytesAvailable, bufferSize;
                byte[] buffer;
                int maxBufferSize = 1 * 1024 * 1024;
                File sourceFile = new File(sourceFileUri);

                if (!sourceFile.isFile()) {

                    dialog.dismiss();

                    Log.e("uploadFile", "Source File not exist :"
                            + uploadFilePath + "" + uploadFileName);

                    runOnUiThread(new Runnable() {
                        public void run() {
                            editText.setText("Source File not exist :"
                                    + uploadFilePath + "" + uploadFileName);
                        }
                    });

                    return 0;

                } else {
                    try {

                        // open a URL connection to the Servlet
                        FileInputStream fileInputStream = new FileInputStream(sourceFile);
                        URL url = new URL(upLoadServerUri);

                        // Open a HTTP  connection to  the URL
                        conn = (HttpURLConnection) url.openConnection();
                        conn.setDoInput(true); // Allow Inputs
                        conn.setDoOutput(true); // Allow Outputs
                        conn.setUseCaches(false); // Don't use a Cached Copy
                        conn.setRequestMethod("POST");
                        conn.setRequestProperty("Connection", "Keep-Alive");
                        conn.setRequestProperty("ENCTYPE", "multipart/form-data");
                        conn.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);
                        conn.setRequestProperty("uploaded_file", fileName);

                        dos = new DataOutputStream(conn.getOutputStream());

                        dos.writeBytes(twoHyphens + boundary + lineEnd);

                        dos.writeBytes(lineEnd);

                        // create a buffer of  maximum size
                        bytesAvailable = fileInputStream.available();

                        bufferSize = Math.min(bytesAvailable, maxBufferSize);
                        buffer = new byte[bufferSize];

                       // clientSocket = serverSocket.accept(); // accept the client connection
                  //      inputStreamReader = new InputStreamReader(clientSocket.getInputStream());
               //         bufferedReader = new BufferedReader(inputStreamReader); // get the client message
                 //       message = bufferedReader.readLine();
                        // read file and write it into form...
                        bytesRead = fileInputStream.read(buffer, 0, bufferSize);

                        while (bytesRead > 0) {

                            dos.write(buffer, 0, bufferSize);
                            bytesAvailable = fileInputStream.available();
                            bufferSize = Math.min(bytesAvailable, maxBufferSize);
                            bytesRead = fileInputStream.read(buffer, 0, bufferSize);

                        }

                        // send multipart form data necesssary after file data...
                        dos.writeBytes(lineEnd);
                        dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);

                        // Responses from the server (code and message)
                        serverResponseCode = conn.getResponseCode();
                        String serverResponseMessage = conn.getResponseMessage();

                        Log.i("uploadFile", "HTTP Response is : "
                                + serverResponseMessage + ": " + serverResponseCode);

                        if (serverResponseCode == 200) {

                            runOnUiThread(new Runnable() {
                                public void run() {

                                    String msg = "File Upload Completed.\n\n See uploaded file here : \n\n"
                                            + " http://www.androidexample.com/media/uploads/"
                                            + uploadFileName;

                                    editText.setText(msg);
                                    Toast.makeText(MainActivity.this, "File Upload Complete.",
                                            Toast.LENGTH_SHORT).show();
                                }
                            });
                        }

                        //close the streams //
                        fileInputStream.close();
                        dos.flush();
                        dos.close();

                    } catch (MalformedURLException ex) {

                        dialog.dismiss();
                        ex.printStackTrace();

                        runOnUiThread(new Runnable() {
                            public void run() {
                                editText.setText("MalformedURLException Exception : check script url.");
                                Toast.makeText(MainActivity.this, "MalformedURLException",
                                        Toast.LENGTH_SHORT).show();
                            }
                        });

                        Log.e("Upload file to server", "error: " + ex.getMessage(), ex);
                    } catch (Exception e) {

                        dialog.dismiss();
                        e.printStackTrace();

                        runOnUiThread(new Runnable() {
                            public void run() {
                                editText.setText("Got Exception : see logcat ");
                                Toast.makeText(MainActivity.this, "Got Exception : see logcat ",
                                        Toast.LENGTH_SHORT).show();
                            }
                        });

                    }
                    dialog.dismiss();
                    return serverResponseCode;

                } // End else block

            }

            //------ uploadFile code Ends here--

        });

        recieve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String textfor = "ok";
                //sends the message to the server
                if (mTcpClient != null) {
                    mTcpClient.sendMessage("ListingFiles");
                    mTcpClient.sendMessage(textfor);
                }

            }
        });

    }

    public class connectTask extends AsyncTask<String, String, TCPClient> {

        @Override
        protected TCPClient doInBackground(String... messagea) {

            //we create a TCPClient object and
            mTcpClient = new TCPClient(new TCPClient.OnMessageReceived() {
                @Override

                //here the messageReceived method is implemented
                public void messageReceived(String message) {
                    //this method calls the onProgressUpdate
                    publishProgress(message);
                }

                public void writeFile(String messagea) throws IOException {

                    System.out.println(messagea);

                    File SDCardRoot = Environment.getExternalStorageDirectory();
                    if (SDCardRoot.canWrite()) {
                        File file = new File(SDCardRoot, "b.txt");


                        FileOutputStream fout = null;
                        try {
                            System.out.println("inside try");
                            fout = new FileOutputStream(file);
                            int ch;
                            String temp;
                            do {
                                fout= new FileOutputStream(file);
                                temp = messagea;
                                System.out.println(messagea + "hiiii");
                                ch = Integer.parseInt(temp);
                                if (ch != -1) {
                                    fout.write(ch);
                                }
                            } while (ch != -1);
                            System.out.println("done before fout close");
                            fout.close();
                            System.out.println("done");
                        } catch (IOException e) {
                            System.out.println("NO Success" + e.getMessage());
                        }
                    }
                }

            });
            mTcpClient.run();

            return null;
        }
//InputStreamReader inputStreamReader = new InputStreamReader(client.getInputStream());
//BufferedReader bufferedReader = new BufferedReader(inputStreamReader); // get the client message

        //String name = bufferedReader.readLine();
//client = new Socket("192.168.43.168", 4444);
        //      Log.d("filename", "hii");
        //    BufferedReader br = new BufferedReader(new FileReader(path + "/networks/"+name));
        //  StringBuilder sb = new StringBuilder();
        //String line = br.readLine();
        //Log.d("filename1", line);
        //while (line != null) {
        // sb.append(line);
        // sb.append(System.lineSeparator());
        //line = br.readLine();
        // }
        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);

            //in the arrayList we add the messaged received from server
            arrayList.add(values[0]);

            mAdapter.notifyDataSetChanged();
        }
    }
}
//	PrintWriter printwriter1 = new PrintWriter(clientSocket.getOutputStream(), true);
//printwriter1.write(name); // write the message to output stream

 //       printwriter1.flush();
  //      printwriter1.close();
